using AltV.Net;
using AltV.Net.Elements.Entities;
using AltV.Net.Async;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Timers;
using Newtonsoft.Json;

namespace DriftScore
{
    public class Main : AsyncResource
    {
        private Dictionary<IPlayer, PlayerDriftData> driftData = new Dictionary<IPlayer, PlayerDriftData>();
        private List<DriftLeaderboardEntry> leaderboard = new List<DriftLeaderboardEntry>();
        private Timer saveTimer;
        private string savePath;

        public override void OnStart()
        {
            savePath = Path.Combine(Alt.Resource.Path, "data", "scores.json");
            
            Alt.Log("[DriftScore] Resource gestartet");
            
            Alt.OnPlayerConnect += OnPlayerConnect;
            Alt.OnPlayerDisconnect += OnPlayerDisconnect;
            
            saveTimer = new Timer(60000);
            saveTimer.Elapsed += (s, e) => SaveLeaderboard();
            saveTimer.Start();
            
            LoadLeaderboard();
        }

        public override void OnStop()
        {
            saveTimer?.Stop();
            SaveLeaderboard();
            Alt.Log("[DriftScore] Resource gestoppt");
        }

        private void OnPlayerConnect(IPlayer player, string reason)
        {
            driftData[player] = new PlayerDriftData();
            
            var entry = leaderboard.FirstOrDefault(x => x.Name == player.Name);
            if (entry != null)
            {
                player.Emit("drift:loadHighscore", entry.Score);
            }
            
            SendLeaderboard(player);
        }

        private void OnPlayerDisconnect(IPlayer player, string reason)
        {
            if (driftData.ContainsKey(player))
            {
                var data = driftData[player];
                if (data.SessionBest > 0)
                {
                    UpdateLeaderboard(player.Name, data.SessionBest);
                }
                driftData.Remove(player);
            }
        }

        [ClientEvent("drift:submitScore")]
        public void OnDriftScoreSubmit(IPlayer player, int score)
        {
            if (!driftData.ContainsKey(player)) return;
            
            var data = driftData[player];
            
            if (score > data.SessionBest)
            {
                data.SessionBest = score;
                player.Emit("drift:newSessionBest", score);
            }
            
            data.TotalScore += score;
            data.DriftCount++;
        }

        [ClientEvent("drift:requestLeaderboard")]
        public void OnLeaderboardRequest(IPlayer player)
        {
            SendLeaderboard(player);
        }

        private void UpdateLeaderboard(string name, int score)
        {
            var existing = leaderboard.FirstOrDefault(x => x.Name == name);
            
            if (existing != null)
            {
                if (score > existing.Score)
                {
                    existing.Score = score;
                    existing.Date = DateTime.Now;
                }
            }
            else
            {
                leaderboard.Add(new DriftLeaderboardEntry
                {
                    Name = name,
                    Score = score,
                    Date = DateTime.Now
                });
            }
            
            leaderboard = leaderboard.OrderByDescending(x => x.Score).Take(50).ToList();
            
            foreach (var p in Alt.GetAllPlayers())
            {
                SendLeaderboard(p);
            }
        }

        private void SendLeaderboard(IPlayer player)
        {
            var top10 = leaderboard.Take(10).Select(x => new { name = x.Name, score = x.Score }).ToArray();
            player.Emit("drift:leaderboard", JsonConvert.SerializeObject(top10));
        }

        private void LoadLeaderboard()
        {
            try
            {
                if (File.Exists(savePath))
                {
                    var json = File.ReadAllText(savePath);
                    leaderboard = JsonConvert.DeserializeObject<List<DriftLeaderboardEntry>>(json) ?? new List<DriftLeaderboardEntry>();
                    Alt.Log($"[DriftScore] {leaderboard.Count} Eintraege geladen");
                }
            }
            catch (Exception ex)
            {
                Alt.LogError($"[DriftScore] Fehler beim Laden: {ex.Message}");
            }
        }

        private void SaveLeaderboard()
        {
            try
            {
                var dir = Path.GetDirectoryName(savePath);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                
                var json = JsonConvert.SerializeObject(leaderboard, Formatting.Indented);
                File.WriteAllText(savePath, json);
            }
            catch (Exception ex)
            {
                Alt.LogError($"[DriftScore] Fehler beim Speichern: {ex.Message}");
            }
        }
    }

    public class PlayerDriftData
    {
        public int SessionBest { get; set; }
        public int TotalScore { get; set; }
        public int DriftCount { get; set; }
    }

    public class DriftLeaderboardEntry
    {
        public string Name { get; set; }
        public int Score { get; set; }
        public DateTime Date { get; set; }
    }
}

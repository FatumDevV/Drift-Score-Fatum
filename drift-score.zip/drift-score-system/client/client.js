import * as alt from 'alt-client';
import * as native from 'natives';

let webview = null;
let isHudVisible = true;

let currentScore = 0;
let multiplier = 1;
let comboTimer = null;
let isDrifting = false;
let driftStartTime = 0;
let personalBest = 0;
let sessionBest = 0;

const config = {
    minSpeed: 15.0,
    minAngle: 15.0,
    maxAngle: 90.0,
    basePoints: 10,
    comboTimeout: 1500,
    maxMultiplier: 5,
    updateInterval: 50
};

alt.on('connectionComplete', () => {
    webview = new alt.WebView('http://resource/ui/index.html');
    
    webview.on('uiReady', () => {
        updateHud();
    });
    
    alt.setInterval(checkDrift, config.updateInterval);
});

alt.onServer('drift:loadHighscore', (score) => {
    personalBest = score;
    updateHud();
});

alt.onServer('drift:newSessionBest', (score) => {
    sessionBest = score;
    updateHud();
});

alt.onServer('drift:leaderboard', (json) => {
    if (webview) {
        webview.emit('updateLeaderboard', json);
    }
});

function checkDrift() {
    const player = alt.Player.local;
    if (!player.vehicle) {
        if (isDrifting) endDrift();
        return;
    }
    
    const veh = player.vehicle;
    if (native.getPedInVehicleSeat(veh, -1, false) !== player) {
        if (isDrifting) endDrift();
        return;
    }
    
    const speed = native.getEntitySpeed(veh) * 3.6;
    if (speed < config.minSpeed) {
        if (isDrifting) endDrift();
        return;
    }
    
    const vel = native.getEntityVelocity(veh);
    const rot = native.getEntityRotation(veh, 2);
    
    const velAngle = Math.atan2(vel.y, vel.x) * (180 / Math.PI);
    const heading = rot.z;
    
    let driftAngle = Math.abs(velAngle - heading);
    if (driftAngle > 180) driftAngle = 360 - driftAngle;
    
    if (driftAngle >= config.minAngle && driftAngle <= config.maxAngle) {
        if (!isDrifting) startDrift();
        
        const angleBonus = driftAngle / config.maxAngle;
        const speedBonus = Math.min(speed / 100, 2);
        const points = Math.floor(config.basePoints * angleBonus * speedBonus * multiplier);
        
        currentScore += points;
        
        if (comboTimer) {
            alt.clearTimeout(comboTimer);
        }
        comboTimer = alt.setTimeout(() => {
            multiplier = Math.min(multiplier + 0.5, config.maxMultiplier);
        }, 200);
        
        updateHud();
    } else if (isDrifting) {
        resetComboTimer();
    }
}

function startDrift() {
    isDrifting = true;
    driftStartTime = Date.now();
    
    if (webview) {
        webview.emit('driftStart');
    }
}

function endDrift() {
    if (!isDrifting) return;
    
    isDrifting = false;
    
    if (currentScore > 0) {
        alt.emitServer('drift:submitScore', currentScore);
        
        if (currentScore > sessionBest) {
            sessionBest = currentScore;
        }
        
        if (webview) {
            webview.emit('driftEnd', currentScore);
        }
    }
    
    currentScore = 0;
    multiplier = 1;
    
    if (comboTimer) {
        alt.clearTimeout(comboTimer);
        comboTimer = null;
    }
    
    updateHud();
}

function resetComboTimer() {
    if (comboTimer) {
        alt.clearTimeout(comboTimer);
    }
    
    comboTimer = alt.setTimeout(() => {
        endDrift();
    }, config.comboTimeout);
}

function updateHud() {
    if (!webview) return;
    
    webview.emit('updateScore', {
        score: currentScore,
        multiplier: multiplier,
        sessionBest: sessionBest,
        personalBest: personalBest,
        isDrifting: isDrifting
    });
}

alt.on('keydown', (key) => {
    if (key === 0x4C) {
        alt.emitServer('drift:requestLeaderboard');
        if (webview) {
            webview.emit('toggleLeaderboard');
        }
    }
    
    if (key === 0x55) {
        isHudVisible = !isHudVisible;
        if (webview) {
            webview.emit('toggleHud', isHudVisible);
        }
    }
});

# Drift Score System

## Installation

1. BUILD.bat doppelklicken (braucht .NET 6 SDK)
2. Den `drift-score` Ordner nach `altv-server/resources/` kopieren
3. In `server.toml` eintragen:

```toml
resources = [
    "drift-score"
]
```

4. Server starten

## Controls

- **[L]** - Leaderboard anzeigen
- **[U]** - HUD ein/ausblenden

## Features

- Echtzeit Drift-Erkennung
- Combo Multiplier (bis x5)
- Session Best / Personal Best
- Leaderboard Top 10
- Scores werden automatisch gespeichert
